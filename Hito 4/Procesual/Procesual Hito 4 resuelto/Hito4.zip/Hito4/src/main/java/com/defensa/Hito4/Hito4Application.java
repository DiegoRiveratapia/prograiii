package com.defensa.Hito4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Hito4Application {

	public static void main(String[] args) {
		SpringApplication.run(Hito4Application.class, args);
	}

}
