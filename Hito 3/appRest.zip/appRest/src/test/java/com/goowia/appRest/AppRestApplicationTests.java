package com.goowia.appRest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
